/* This code is an updated version of the sample code from "Computer Networks: A
 * Systems Approach," 5th Edition by Larry L. Peterson and Bruce S. Davis. Some
 * code comes from man pages, mostly getaddrinfo(3). */

 // Group 2: Clayton Jacobs, Campbell Crowley
 // CSCI 446, Fall 2019
#include <fcntl.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

const size_t buf_size = 1000;

/*
 * Lookup a host IP address and connect to it using service. Arguments match the
 * first two arguments to getaddrinfo(3).
 *
 * Returns a connected socket descriptor or -1 on error. Caller is responsible
 * for closing the returned socket.
 */
int lookup_and_connect(const char *host, const char *service);

int main(int argc, char *argv[]) {
  char buf[buf_size];
  int s;
  char *host;
  char *port;
  char *filename;

  if (argc == 4) {
    host = argv[1];
    port = argv[2];
    filename = argv[3];
  } else {
    fprintf(stderr, "usage: %s host port filename\n", argv[0]);
    return 1;
  }

  /* Lookup IP and connect to server */
  if ((s = lookup_and_connect(host, port)) < 0) {
    return 1;
  }

  size_t len = strlen(filename);

  int total = 0;
  size_t bytesLeft = len;
  ssize_t n;
  while ((n = send(s, filename + total, bytesLeft, 0)) > 0) {
    total += n;
    bytesLeft -= (size_t)n;
  }
  if (n == -1) {
    perror("Socket Closed");
    close(s);
    return 1;
  }

  while ((n = recv(s, buf, buf_size, 0)) > 0) {
    if (buf[0] != '+') {
      close(s);
      fprintf(stderr, "Server Error: %s\n", buf);
      return 1;
    } else {
      int fd = open(filename, O_WRONLY | O_TRUNC | O_CREAT, 0666);
      if (fd == -1) {
        perror("Unable to open output file");
        close(fd);
        close(s);
        return 1;
      }
      int o = 1;
      if (n > 0) n--;
      do {
        if (n > 0) {
          n = write(fd, buf + o, (size_t)n);
          if (n == -1) {
            perror("Failed to write to file");
            close(fd);
            close(s);
            return 1;
          }
        }
        o = 0;
      } while((n = recv(s, buf, buf_size, 0)) > 0);
      close(fd);
      if (n == -1) {
        close(s);
        perror("Failed to receive data");
        return 1;
      }
    }
  }
  close(s);

  if (n == -1) {
    perror("Socket Closed");
    return 1;
  }

  return 0;
}

int lookup_and_connect(const char *host, const char *service) {
  struct addrinfo hints;
  struct addrinfo *rp, *result;
  int s;

  /* Translate host name into peer's IP address */
  memset(&hints, 0, sizeof(hints));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = 0;
  hints.ai_protocol = 0;

  if ((s = getaddrinfo(host, service, &hints, &result)) != 0) {
    fprintf(stderr, "client: getaddrinfo: %s\n", gai_strerror(s));
    return -1;
  }

  /* Iterate through the address list and try to connect */
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    if ((s = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol)) == -1) {
      continue;
    }

    if (connect(s, rp->ai_addr, rp->ai_addrlen) != -1) {
      break;
    }

    close(s);
  }
  if (rp == NULL) {
    perror("client: connect");
    return -1;
  }
  freeaddrinfo(result);

  return s;
}
